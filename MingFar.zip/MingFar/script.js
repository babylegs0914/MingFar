// 暂时留空，方便以后添加动态功能
console.log("MingFar website loaded");
